
/*
 *  First Java Program
 */
//Package name
package com.edu.cprogram;

//Class 
public class FirstClass {

	//main method
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Welcome to Java World  by  Prof. Jayvant Devare"); // printing on console
	}

}
